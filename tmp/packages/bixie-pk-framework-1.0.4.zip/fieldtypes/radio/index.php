<?php
return [
	'id' => 'radio',
	'label' => __('Radio bullets'),
	'config' => [
		'hasOptions' => 1,
		'required' => 0,
		'multiple' => 1,
	]
];