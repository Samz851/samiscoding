<?php


namespace Bixie\PkFramework\FieldType\Upload;

use Bixie\PkFramework\FieldType\FieldTypeUpload;

class UploadFieldType extends FieldTypeUpload {

}