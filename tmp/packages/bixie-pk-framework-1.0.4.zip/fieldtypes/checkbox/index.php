<?php
return [
	'id' => 'checkbox',
	'label' => __('Checkboxes'),
	'config' => [
		'hasOptions' => 1,
		'required' => 0,
		'multiple' => 1,
	]
];