<?php
return [
	'id' => 'text',
	'label' => __('Textfield'),
	'config' => [
		'hasOptions' => 0,
		'required' => -1,
		'multiple' => 0,
		'placeholder' => ''
	]
];