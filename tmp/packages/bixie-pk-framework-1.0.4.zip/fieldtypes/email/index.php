<?php
return [
	'id' => 'email',
	'label' => __('Email field'),
	'config' => [
		'hasOptions' => 0,
		'required' => -1,
		'multiple' => 0,
		'placeholder' => ''
	]
];