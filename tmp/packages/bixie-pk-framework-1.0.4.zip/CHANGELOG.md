1.0.4 (December 7, 2016)

- Add version cache breaker
- Fix loading dependancies

1.0.3 (December 7, 2016)

- Add location fieldtype
- Combine fieldtype scripts
- Added agreed fieldtype
- Ajax function calls for fieldtypes
- Field loading optimization

1.0.2 (December 1, 2016)

- Fix loading html editor
- No min/max length in admin

1.0.1 (November 30, 2016)

- Added components for emailsender, cart
- Fixed bablify settings

1.0.0 (November 9, 2016)

- Initial release
