<?php
/* *
 *	Bixie Printshop
 *  Field.php
 *	Created on 13-12-2015 20:06
 *  
 *  @author Matthijs
 *  @copyright Copyright (C)2015 Bixie.nl
 *
 */


namespace Bixie\PkFramework\FieldType;


class FieldType extends FieldTypeBase {

}